package org.notariado.ancert.minotaria;

import org.notariado.ancert.minotaria.model.Customer;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.util.LinkedHashMap;
import java.util.List;


public class SpringBootRestTestClient {

    public static final String REST_SERVICE_URI = "http://localhost:8080//C-APP/api";

    /* POST */
    private static void createCustomer() {
        System.out.println("Testing create Customer API----------");
        RestTemplate restTemplate = new RestTemplate();
        Customer customer = new Customer("PC", "3", 500);
        URI uri = restTemplate.postForLocation(REST_SERVICE_URI + "/customer/", customer, Customer.class);
        System.out.println("Location : " + uri.toASCIIString());
    }

    /* GET */
    @SuppressWarnings("unchecked")
    private static void listAllCustomers() {
        System.out.println("Testing listAllCustomers API-----------");

        RestTemplate restTemplate = new RestTemplate();
        List<LinkedHashMap<String, Object>> customersMap = restTemplate.getForObject(REST_SERVICE_URI + "/customer/", List.class);

        if (customersMap != null) {
            for (LinkedHashMap<String, Object> map : customersMap) {
                System.out.println("Customer : id=" + map.get("id") + ", Name=" + map.get("name") + ", categoryId=" + map.get("categoryId") + ", Price=" + map.get("price"));
            }
        } else {
            System.out.println("No customer exist----------");
        }
    }

    /* GET */
    private static void getCustomer() {
        System.out.println("Testing getCustomer API----------");
        RestTemplate restTemplate = new RestTemplate();
        Customer customer = restTemplate.getForObject(REST_SERVICE_URI + "/customer/1", Customer.class);
        System.out.println(customer);
    }

    /* PUT */
    private static void updateCustomer() {
        System.out.println("Testing update Customer API----------");
        RestTemplate restTemplate = new RestTemplate();
        Customer customer = new Customer("Book", "3", 70000);
        restTemplate.put(REST_SERVICE_URI + "/customer/1", customer);
        System.out.println(customer);
    }

    /* DELETE */
    private static void deleteCustomer() {
        System.out.println("Testing delete Customer API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI + "/customer/1");
    }


    /* DELETE */
    private static void deleteAllCustomers() {
        System.out.println("Testing all delete Customers API----------");
        RestTemplate restTemplate = new RestTemplate();
        restTemplate.delete(REST_SERVICE_URI + "/customer/");
    }

    public static void main(String args[]) {
        listAllCustomers();
        getCustomer();
        createCustomer();
        listAllCustomers();
        updateCustomer();
        listAllCustomers();
        deleteCustomer();
        listAllCustomers();
        deleteAllCustomers();
        listAllCustomers();
    }
}
