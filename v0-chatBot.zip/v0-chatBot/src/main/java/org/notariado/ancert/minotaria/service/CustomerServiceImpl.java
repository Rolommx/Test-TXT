package org.notariado.ancert.minotaria.service;

import org.notariado.ancert.minotaria.model.Customer;
import org.notariado.ancert.minotaria.repositories.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Objects; 


@Service("CustomerService")
public class CustomerServiceImpl implements CustomerService {

    private final CustomerRepository customerRepository;

    @Autowired
    public CustomerServiceImpl(CustomerRepository customerRepository) {
        this.customerRepository = customerRepository;
    }


    public List<Customer> findAllCustomers() {
        // Pagination should be added...
        return customerRepository.findAll();
    }

    public Customer findById(long id) {
        return customerRepository.findById(id).orElse(null);
    }

    public List<Customer> findByName(String name) {
        return customerRepository.findByName(name);

    }
    
     public Customer createCustomer(Customer customer){
     	 customer.setId(null); 
     	 return  customerRepository.save(customer);
     	}

    public void saveCustomer(Customer Customer) {
        //Customer.setId(null);
        customerRepository.save(Customer);
    }

    public void updateCustomer(Customer Customer) {
        saveCustomer(Customer);
    }

    public void deleteCustomerById(long id) {
        customerRepository.deleteById(id);
    }

    public boolean isCustomerExist(Customer Customer) {
        return Objects.nonNull(Customer.getId()) &&  customerRepository.existsById(Customer.getId());
    }

    public void deleteAllCustomers() {
        customerRepository.deleteAll();
    }

    @Override
    public Customer findByDni(String dni) {
       List<Customer> byDni = customerRepository.findByDniIs(dni);
        return byDni.isEmpty() ? null : byDni.get(0);
    }

}
