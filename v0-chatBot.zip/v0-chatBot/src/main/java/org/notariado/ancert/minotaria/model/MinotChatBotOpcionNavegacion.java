package org.notariado.ancert.minotaria.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "MINOT_CHAT_BOT_OPCINES_NAVEGACION")
public class MinotChatBotOpcionNavegacion implements Serializable {
    private static final long serialVersionUID = -4763184776396462691L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ID_NAVEGACION", nullable = false)
    private MinotChatBotNavegacion navegacion;;

    @Column(name = "MENSAJE")
    private String mensaje;

    @Column(name = "ORDEN")
    private Integer orden;

    @Column(name = "CLAVE_NAVEGACION_SGTE")
    private String irAClaveNavegacion;

    @Column(name = "ES_REGRESAR")
    private Integer esRegresar;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MinotChatBotNavegacion getNavegacion() {
        return navegacion;
    }

    public void setNavegacion(MinotChatBotNavegacion navegacion) {
        this.navegacion = navegacion;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getIrAClaveNavegacion() {
        return irAClaveNavegacion;
    }

    public void setIrAClaveNavegacion(String irAClaveNavegacion) {
        this.irAClaveNavegacion = irAClaveNavegacion;
    }

    public Integer getEsRegresar() {
        return esRegresar;
    }

    public void setEsRegresar(Integer esRegresar) {
        this.esRegresar = esRegresar;
    }
}