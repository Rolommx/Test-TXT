package org.notariado.ancert.minotaria.enums;

import java.util.Arrays;

public enum EnumChatBotTipoMensaje {
    MENSAJE("MT"),
    PREGUNTA("PR"),
    TEXTO_INFORMACION("TI"),
    REGRESAR("RE"),
    OPCION("OP");

    private final String code;

    EnumChatBotTipoMensaje(String code) {
        this.code = code;
    }

    public static EnumChatBotTipoMensaje byCodigo(String tipoMensaje) {
        return Arrays.stream(EnumChatBotTipoMensaje.values()).filter(el -> el.getCode().equalsIgnoreCase(tipoMensaje)).findAny()
            .orElse(EnumChatBotTipoMensaje.MENSAJE);
    }

    public String getCode() {
        return code;
    }
}
