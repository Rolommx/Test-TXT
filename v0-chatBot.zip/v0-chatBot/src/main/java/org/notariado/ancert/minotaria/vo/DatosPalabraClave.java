package org.notariado.ancert.minotaria.vo;

public class DatosPalabraClave {
    private String irANivelOrder;
    private Integer subOrden;

    public DatosPalabraClave(String irANivelOrder, Integer subOrden) {
        this.irANivelOrder = irANivelOrder;
        this.subOrden = subOrden;
    }

    public String getIrANivelOrder() {
        return irANivelOrder;
    }

    public void setIrANivelOrder(String irANivelOrder) {
        this.irANivelOrder = irANivelOrder;
    }

    public Integer getSubOrden() {
        return subOrden;
    }

    public void setSubOrden(Integer subOrden) {
        this.subOrden = subOrden;
    }
}
