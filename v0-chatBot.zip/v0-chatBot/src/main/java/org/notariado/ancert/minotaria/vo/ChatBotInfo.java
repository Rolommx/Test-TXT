package org.notariado.ancert.minotaria.vo;

import java.util.ArrayList;
import java.util.List;

import org.notariado.ancert.minotaria.enums.EnumChatBotTipoMensaje;


public class ChatBotInfo {
    private String claveNavegacion;
    private String textoInformativo;
    private String irANavegacion;
    private int orden;
    private EnumChatBotTipoMensaje tipoMensaje;
    private String mensaje;
    private List<Opciones> opciones;


    public ChatBotInfo(String claveNavegacion, String textoInformativo, String irANavegacion, Integer orden, String tipoMensaje, String mensaje,
        List<Opciones> opciones) {
        this.claveNavegacion = claveNavegacion;
        this.textoInformativo = textoInformativo;
        this.irANavegacion = irANavegacion;
        this.orden = orden != null ? orden.intValue() : 0;
        this.tipoMensaje = EnumChatBotTipoMensaje.byCodigo(tipoMensaje);
        this.mensaje = mensaje;
        this.opciones = opciones;
    }

    public ChatBotInfo(String claveNavegacion, String textoInformativo, String irANavegacion, Integer orden, String tipoMensaje,
        String mensaje) {
        this(claveNavegacion, textoInformativo, irANavegacion, orden, tipoMensaje, mensaje, new ArrayList<>());
    }

    public String getClaveNavegacion() {
        return claveNavegacion;
    }

    public void setClaveNavegacion(String claveNavegacion) {
        this.claveNavegacion = claveNavegacion;
    }

    public String getTextoInformativo() {
        return textoInformativo;
    }

    public void setTextoInformativo(String textoInformativo) {
        this.textoInformativo = textoInformativo;
    }

    public String getIrANavegacion() {
        return irANavegacion;
    }

    public void setIrANavegacion(String irANavegacion) {
        this.irANavegacion = irANavegacion;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }

    public EnumChatBotTipoMensaje getTipoMensaje() {
        return tipoMensaje;
    }

    public void setTipoMensaje(EnumChatBotTipoMensaje tipoMensaje) {
        this.tipoMensaje = tipoMensaje;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public List<Opciones> getOpciones() {
        if (opciones == null) {
            opciones = new ArrayList<>();
        }
        return opciones;
    }

    public void setOpciones(List<Opciones> opciones) {
        this.opciones = opciones;
    }
}
