package org.notariado.ancert.minotaria.util;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Predicate;
import java.util.stream.Collectors;

public class StringUtils {

    private static final Map<Character,Character> replace = new HashMap<>(5);
    private static final Set<String> excluirPalabras = new HashSet<>();
    static {
        replace.put('á','a');
        replace.put('é','e');
        replace.put('í','i');
        replace.put('ó','o');
        replace.put('ú','u');
        replace.put('ü','u');
        replace.put('ñ','n');
        excluirPalabras.add("la");
        excluirPalabras.add("de");
        excluirPalabras.add("las");
        excluirPalabras.add("el");
        excluirPalabras.add("los");
        excluirPalabras.add("en");
        excluirPalabras.add("del");

    }
    public static final String normalize(String words){
        char[] lower = words.toLowerCase(Locale.ENGLISH).toCharArray();
        StringBuilder stringWriter = new StringBuilder(lower.length);
        for(int i=0; i< lower.length; i++ )
            stringWriter.append(replace.getOrDefault(lower[i],lower[i]));
        return stringWriter.toString();
    }

    public static String quoteAndEscapeSql(String str) {
        StringBuilder buffer = new StringBuilder(str != null ? str.length() : 5);
        if (str == null) {
            buffer.append(" NULL ");
        } else {
           // @formatter:off
            buffer.append('\'')
                .append(str.replace("'", "''"))
                .append('\'');
           // @formatter:on

        }
        return buffer.toString();
    }

    public static List<String> tokenize(String arg , boolean soloPalabras ) {
        if (arg == null) {
            return Collections.emptyList();
        }
        Predicate<String> quitarExcluidas = str -> str.length() >1 &&   !excluirPalabras.contains(str) ;
        return Arrays.stream(arg.trim().split("\\s+|\\t|\\n|\\r|\\f|\\.+|\\,+|;|-|:"))
            .distinct()
            .filter(str -> !str.trim().isEmpty())
            .filter(str -> (!soloPalabras || quitarExcluidas.test(str)))
            .collect(Collectors.toList());
    }


}
