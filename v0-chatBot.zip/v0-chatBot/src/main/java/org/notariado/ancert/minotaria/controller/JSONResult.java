package org.notariado.ancert.minotaria.controller;

public class JSONResult {

    private boolean success;

    private String message;

    private Object data;

    public JSONResult(boolean success, String message, Object data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }

    public boolean isSuccess() {
        return success;
    }

    public String getMessage() {
        return message;
    }

    public Object getData() {
        return data;
    }
}
