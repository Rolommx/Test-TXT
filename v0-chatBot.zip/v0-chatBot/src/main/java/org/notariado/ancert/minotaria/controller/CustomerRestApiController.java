package org.notariado.ancert.minotaria.controller;

import org.notariado.ancert.minotaria.model.Customer;
import org.notariado.ancert.minotaria.service.CustomerService;
import org.notariado.ancert.minotaria.util.CustomErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
 

import java.util.List;
import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin( value = {"*"})
public class CustomerRestApiController {

    public static final Logger logger = LoggerFactory.getLogger(CustomerRestApiController.class);

    @Autowired
    CustomerService CustomerService; //Service which will do all data retrieval/manipulation work

    // -------------------Retrieve All Customers--------------------------------------------

    @RequestMapping(value = "/customer/", method = RequestMethod.GET
    /* , produces = { "application/json"} */)
    public ResponseEntity<List<Customer>> listAllCustomers() {
        List<Customer> Customers = CustomerService.findAllCustomers();
        if (Customers.isEmpty()) {
            return new ResponseEntity<>(Customers, HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(Customers, HttpStatus.OK);
    }

    // -------------------Retrieve Single Customer------------------------------------------

    @RequestMapping(value = "/customer/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> getCustomer(@PathVariable("id") long id) {
        logger.info("Fetching Customer with id {}", id);
        Customer Customer = CustomerService.findById(id);
        if (Customer == null) {
            logger.error("Customer with id {} not found.", id);
            return new ResponseEntity<>(new CustomErrorType("Customer with id " + id  + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(Customer, HttpStatus.OK);
    }

    @RequestMapping(value = "/customer/by-dni/{dni}", method = RequestMethod.GET)
    public ResponseEntity<?> getCustomerByDNI(@PathVariable("dni") String dni) {
        logger.info("Fetching Customer with DNI {}", dni);
        Customer Customer = CustomerService.findByDni(dni);
        if (Customer == null) {
            logger.error("Customer with DNI {} not found.", dni);
            return new ResponseEntity<>(new CustomErrorType("Customer with id " + dni  + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<>(Customer, HttpStatus.OK);
    }

    // -------------------Create a Customer-------------------------------------------

    @RequestMapping(value = "/customer/", method = RequestMethod.POST)
    public ResponseEntity<?> createCustomer(@RequestBody Customer customer) {
        logger.info("Creating Customer : {}", customer);

        if (CustomerService.isCustomerExist(customer)) {
            logger.error("Unable to create. A Customer with name {} already exist", customer.getName());
            return new ResponseEntity<>(new CustomErrorType("Unable to create. A Customer with name " +
                    customer.getName() + " already exist."), HttpStatus.CONFLICT);
        }
         
       Customer created= CustomerService.createCustomer(customer);

        return new ResponseEntity<>(created, HttpStatus.CREATED);
    }

    // ------------------- Update a Customer ------------------------------------------------

    @RequestMapping(value = "/customer/{id}", method = RequestMethod.PUT)
    public ResponseEntity<?> updateCustomer(@PathVariable("id") long id, @RequestBody Customer customer) {
        logger.info("Updating Customer with id {}", id);
        
        if( customer.getAge() <12 ){
        	 
          return new ResponseEntity<>( buildError(),
                    HttpStatus.OK);
        }
        
        Customer currentCustomer = CustomerService.findById(id);

        if (currentCustomer == null) {
            logger.error("Unable to update. Customer with id {} not found.", id);
            return new ResponseEntity<>(new CustomErrorType("Unable to upate. Customer with id " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }
        currentCustomer.setId(id);
        currentCustomer.setName(customer.getName());
        currentCustomer.setAge(customer.getAge());
        currentCustomer.setDni(customer.getDni());
        currentCustomer.setResume(customer.getResume());

        CustomerService.updateCustomer(currentCustomer);
        return new ResponseEntity<>(currentCustomer, HttpStatus.OK);
    }

    // ------------------- Delete a Customer-----------------------------------------

    @RequestMapping(value = "/customer/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> deleteCustomer(@PathVariable("id") long id) {
        logger.info("Fetching & Deleting Customer with id {}", id);

        Customer Customer = CustomerService.findById(id);
        if (Customer == null) {
            logger.error("Unable to delete. Customer with id {} not found.", id);
            return new ResponseEntity<>(new CustomErrorType("Unable to delete. Customer with id " + id + " not found."),
                    HttpStatus.NOT_FOUND);
        }
        CustomerService.deleteCustomerById(id);
        Map<String,Object> result= new  HashMap<>();
        result.put("deleted",true);
        result.put("id",id);
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
   private Map<String,Object> buildError(){
   	 Map<String,Object> error= new  HashMap<>();
   	 error.put("error",true);
   	 Map<String,String> validation= new  HashMap<>();;
	        ;
	  validation.put("age","NOOOO... Debe ser menor de edad");      
	  validation.put("name","El nombre es incorrecto");     
	 
	  error.put("validation",validation);
	  
	   
	    return error   ;      
	 	}
 
}
