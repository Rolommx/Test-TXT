package org.notariado.ancert.minotaria.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "MINOT_CHAT_BOT_PALABRA_CLAVE")
public class MinotChatBotPalabraClave implements Serializable {
    private static final long serialVersionUID = 8898254999118647482L;

    @Id
    @SequenceGenerator(name = "MINOT_CHAT_BOT_PALABRA_CLAVES_GENERATOR", sequenceName = "SQ_MINOT_CHAT_BOT_PALABRA_CLAVE")
    @GeneratedValue(strategy = GenerationType.AUTO, generator = "MINOT_CHAT_BOT_PALABRA_CLAVES_GENERATOR")
    @Column(name = "ID_PALABRA_CLAVE")
    private Long idPalabraClave;

    @ManyToOne
    @JoinColumn(name = "ID_APLICACION", nullable = false)
    private MinotChatBotAplicacion aplicacion;


    @Column(name = "PALABRA_CLAVE", nullable = false)
    private String palabraClave;


    @Column(name = "NIVEL_ORDEN", nullable = false)
    private String irANivelOrden;

    @Column(name = "SUB_ORDEN")
    private Integer subOrden;

}