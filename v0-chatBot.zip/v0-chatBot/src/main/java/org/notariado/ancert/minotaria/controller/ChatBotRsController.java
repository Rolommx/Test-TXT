package org.notariado.ancert.minotaria.controller;

import java.util.List;

import org.notariado.ancert.minotaria.business.service.chatbot.ChatBotNavegacionService;
import org.notariado.ancert.minotaria.business.service.chatbot.ChatBotService;
import org.notariado.ancert.minotaria.vo.AplicacionDeChatBot;
import org.notariado.ancert.minotaria.vo.ChatBotInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/MNT/api/v1/chat-bot")
@CrossOrigin(value = {"*"})
@SuppressWarnings("cdi-ambiguous-dependency")
public class ChatBotRsController {


    private Logger log = LoggerFactory.getLogger(ChatBotRsController.class);


    private final ChatBotService chatBotService;
    private final ChatBotNavegacionService navegacionService;

    public ChatBotRsController(ChatBotService chatBotService, ChatBotNavegacionService navegacionService) {
        this.chatBotService = chatBotService;
        this.navegacionService = navegacionService;
    }

    @RequestMapping(value = "/listar-aplicaciones", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<JSONResult> getAplicaciones() {
        List<AplicacionDeChatBot> aplicaciones = chatBotService.aplicacionesDeChatBotsDisponibles();
        return ResponseEntity.ok(new JSONResult(true, "", aplicaciones));
    }


    @RequestMapping(value = "/app-mensaje-por-clave", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})


    public ResponseEntity<JSONResult> getMensajePorAplicacionesYClaveNavegacion(@RequestParam(name = "ID_DE_APLICACION") Long id,
            @RequestParam(name = "CLAVE_NAVEGACION") String claveNavegacion, @RequestParam(name = "APP_CUV" ,required = false) String cuv) {

        if (isBlank(id) || isBlank(claveNavegacion)) {
            return ResponseEntity.ok(new JSONResult(false, "Parametros  ID_DE_APLICACION    y CLAVE_NAVEGACION  Requeridos", null));
        }


        List<ChatBotInfo> mensajesCB = chatBotService.obtenerMensajesPorAppYClaveNavegacion(id, claveNavegacion, cuv);
        boolean encontrado = !mensajesCB.isEmpty();
        String mensajeRespuesta = encontrado ? null : " Clave de navegacion no encontrada";
        return ResponseEntity.ok(new JSONResult(encontrado, mensajeRespuesta, mensajesCB));



    }

    @RequestMapping(value = "/app-navegacion-por-clave", method = RequestMethod.GET, produces = {MediaType.APPLICATION_JSON_VALUE})


    public ResponseEntity<JSONResult> getMensajePorAplicacionesYIDNav(@RequestParam(name = "ID_DE_APLICACION") Long id,
        @RequestParam(name = "CLAVE_NAVEGACION") String claveNavegacion, @RequestParam(name = "APP_CUV" ,required = false) String cuv) {

        if (isBlank(id) || isBlank(claveNavegacion)) {
            return ResponseEntity.ok(new JSONResult(false, "Parametros  ID_DE_APLICACION    y CLAVE_NAVEGACION  Requeridos", null));
        }


        List<ChatBotInfo> mensajesCB = navegacionService.obtenerMensajesPorAppYClaveNavegacion(id, claveNavegacion, cuv);
        boolean encontrado = !mensajesCB.isEmpty();
        String mensajeRespuesta = encontrado ? null : " Clave de navegacion no encontrada";
        return ResponseEntity.ok(new JSONResult(encontrado, mensajeRespuesta, mensajesCB));



    }



    private boolean isBlank(String param) {
        return param == null || param.trim().length() == 0;
    }

    private boolean isBlank(Long param) {
        return param == null || param == 0;
    }
}

