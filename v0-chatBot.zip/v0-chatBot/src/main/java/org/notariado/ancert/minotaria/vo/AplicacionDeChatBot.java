package org.notariado.ancert.minotaria.vo;


import java.io.Serializable;

public class AplicacionDeChatBot implements Serializable {
    private static final long serialVersionUID = -7779391817008268407L;
    private int idAplicacion;
    private String nombre;
    private String mensajeInicial;

    public AplicacionDeChatBot(Long idAplicacion, String nombre, String mensajeInicial) {
        this.idAplicacion = idAplicacion.intValue();
        this.nombre = nombre;
        this.mensajeInicial = mensajeInicial;
    }

    public int getIdAplicacion() {
        return idAplicacion;
    }

    public void setIdAplicacion(int idAplicacion) {
        this.idAplicacion = idAplicacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMensajeInicial() {
        return mensajeInicial;
    }

    public void setMensajeInicial(String mensajeInicial) {
        this.mensajeInicial = mensajeInicial;
    }
}
