package org.notariado.ancert.minotaria.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MinotChatBotPalabraClave.class)
public abstract class MinotChatBotPalabraClave_ {

	public static volatile SingularAttribute<MinotChatBotPalabraClave, String> palabraClave;
	public static volatile SingularAttribute<MinotChatBotPalabraClave, Integer> subOrden;
	public static volatile SingularAttribute<MinotChatBotPalabraClave, String> irANivelOrden;
	public static volatile SingularAttribute<MinotChatBotPalabraClave, MinotChatBotAplicacion> aplicacion;
	public static volatile SingularAttribute<MinotChatBotPalabraClave, Long> idPalabraClave;

}

