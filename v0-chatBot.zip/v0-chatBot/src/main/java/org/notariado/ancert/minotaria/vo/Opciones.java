package org.notariado.ancert.minotaria.vo;

public class Opciones {
    private String textoInformacion;
    private String irANavegacion;
    private int orden;
    private boolean esRegresar;

    public Opciones(String textoInformacion, String irANavegacion, int orden) {
        this.textoInformacion = textoInformacion;
        this.irANavegacion = irANavegacion;
        this.orden = orden;
    }

    public Opciones(String textoInformacion, String irANavegacion, int orden, boolean esRegresar) {
        this(textoInformacion, irANavegacion, orden);
        this.esRegresar = esRegresar;
    }

    public String getTextoInformacion() {
        return textoInformacion;
    }

    public void setTextoInformacion(String textoInformacion) {
        this.textoInformacion = textoInformacion;
    }

    public String getIrANavegacion() {
        return irANavegacion;
    }

    public void setIrANavegacion(String irANavegacion) {
        this.irANavegacion = irANavegacion;
    }

    public int getOrden() {
        return orden;
    }

    public void setOrden(int orden) {
        this.orden = orden;
    }

    public boolean isEsRegresar() {
        return esRegresar;
    }

    public void setEsRegresar(boolean esRegresar) {
        this.esRegresar = esRegresar;
    }
}
