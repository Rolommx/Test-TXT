package org.notariado.ancert.minotaria.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import java.io.Serializable;

@Entity
@Table(name = "MINOT_APLICACION_CHAT_BOT")
public class MinotChatBotAplicacion implements Serializable {
    private static final long serialVersionUID = 8898254999118647482L;

    @Id
    @Column(name = "ID_APLICACION")
    private Long idAplicacion;

    @Column(name = "NOMBRE")
    private String  nombre;

    @Column(name = "LINK_MENSAJE")
    private String  mensajeInicial ;

    @Column(name = "DESCRIPCION")
    private String  descripcion;

    public Long getIdAplicacion() {
        return idAplicacion;
    }

    public void setIdAplicacion(Long idAplicacion) {
        this.idAplicacion = idAplicacion;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getMensajeInicial() {
        return mensajeInicial;
    }

    public void setMensajeInicial(String mensajeInicial) {
        this.mensajeInicial = mensajeInicial;
    }
}