package org.notariado.ancert.minotaria.controller;

import org.notariado.ancert.minotaria.business.service.chatbot.ChatBotService;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/MNT")
public class DLController {

    private final ChatBotService chatBotService;

    public DLController(ChatBotService chatBotService) {
        this.chatBotService = chatBotService;
    }

    @RequestMapping(method = {RequestMethod.GET}, value = "/h2db/dl-data/msg.sql")
    public ResponseEntity<byte[]> downloadSQL() {

        String file = "msg.sql";
        ContentDisposition cd = ContentDisposition.builder("attachment").filename(file).build();
        String sqlInserts = chatBotService.getSQLInsertMsgs();
        return ResponseEntity.status(HttpStatus.OK).header(HttpHeaders.CONTENT_DISPOSITION, cd.toString()).contentType(asMediaType("text/plain"))
            .body(sqlInserts.getBytes());

    }

    private MediaType asMediaType(String mediaType ){
        try {
            return   MediaType.parseMediaType(mediaType);
        } catch (Exception e) {
            return  MediaType.APPLICATION_OCTET_STREAM;
        }
    }

}