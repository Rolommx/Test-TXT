package org.notariado.ancert.minotaria.business.service.chatbot;


import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

import org.notariado.ancert.minotaria.business.vo.chatbot.ChatBotBusquedaDeTexto;
import org.notariado.ancert.minotaria.enums.EnumChatBotTipoMensaje;
import org.notariado.ancert.minotaria.model.MinotChatBotAplicacion;
import org.notariado.ancert.minotaria.model.MinotChatBotMensaje;
import org.notariado.ancert.minotaria.repositories.MinotChatBotAplicacionRepository;
import org.notariado.ancert.minotaria.repositories.MinotChatBotPalabraClaveRepository;
import org.notariado.ancert.minotaria.repositories.MinotChatBotMensajeRepository;
import org.notariado.ancert.minotaria.util.StringUtils;
import org.notariado.ancert.minotaria.vo.AplicacionDeChatBot;
import org.notariado.ancert.minotaria.vo.ChatBotInfo;
import org.notariado.ancert.minotaria.vo.Opciones;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ChatBotServiceImpl implements ChatBotService {
    private static final String NOMBRE = "nombre";
    private static final String FECHA = "fecha";
    private static final String FECHA_AYER = "fecha_ayer";
    private static final String QUINCENA_ACTUAL = "quincena_actual";
    private static final DateFormat DATE_FORMAT = new SimpleDateFormat("dd-MM-yyyy ");



    private static Logger log = LoggerFactory.getLogger(ChatBotServiceImpl.class);



    private final MinotChatBotPalabraClaveRepository chatBotPalabraClaveRepository;
    private final MinotChatBotAplicacionRepository chatBotAplicacionRepository;



    private final MinotChatBotMensajeRepository chatBotMensajeRepository;

    public ChatBotServiceImpl(MinotChatBotPalabraClaveRepository chatBotPalabraClaveRepository,
        MinotChatBotAplicacionRepository chatBotAplicacionRepository, MinotChatBotMensajeRepository chatBotMensajeRepository) {
        this.chatBotPalabraClaveRepository = chatBotPalabraClaveRepository;
        this.chatBotAplicacionRepository = chatBotAplicacionRepository;
        this.chatBotMensajeRepository = chatBotMensajeRepository;
    }



    public List<ChatBotInfo> obtenerMensajesPorAppYClaveNavegacion(Long idApp, String claveNav, String cuv) {
        List<MinotChatBotMensaje>  data =  chatBotMensajeRepository.obtenerPorApicacionYClaveNavegacion(idApp, claveNav);
        if(data.isEmpty()) {
            return Collections.emptyList();
        }
        List<ChatBotInfo> result = data.stream().map(this::toChatBotInfo).collect(Collectors.toList());
        List<Opciones> opciones = new ArrayList<>();

        data.forEach( msg -> {
            if(EnumChatBotTipoMensaje.OPCION.getCode().equalsIgnoreCase( msg.getTipoMensaje()) ){
                opciones.add( this.toOpcion(msg));
            }

        });
       result.get(0).getOpciones().addAll(opciones);
       return result ;
    }

    private Opciones toOpcion(MinotChatBotMensaje msg) {
        return new Opciones(msg.getMensaje(),msg.getIrANivelOrden(),msg.getSubOrden());
    }


    public ChatBotBusquedaDeTexto obtenerMensajesPorAppYTexto(Long idAplicacion, String texto) {

        return new ChatBotBusquedaDeTexto(false, new ArrayList());


    }

    @Override
    public List<AplicacionDeChatBot> aplicacionesDeChatBotsDisponibles() {
        return chatBotAplicacionRepository.findAll().stream().map(this::toAplicacionDeChatBot).collect(Collectors.toList());
    }

    @Override
    public String getSQLInsertMsgs() {
        List<MinotChatBotMensaje> allMsgs = chatBotMensajeRepository.findAll();

      return   allMsgs.stream().map(this::toInsertSQL ).collect(Collectors.joining("\r\n"));
    }

    private String toInsertSQL(MinotChatBotMensaje mensaje) {
        StringBuilder buffer = new StringBuilder(256);
        buffer.append("INSERT INTO MINOT_CHAT_BOT_MENSAJE (ID_MENSAJE,ID_APLICACION,NIVEL_ORDEN,SUB_ORDEN,TIPO_MENSAJE,MENSAJE,IR_A_NIVEL_ORDEN,TXT_INFO)"
            + " VALUES (");
        buffer.append(mensaje.getId() +"              ")
            .append(",")
            .append(mensaje.getAplicacion().getIdAplicacion())
            .append(",")
           .append(StringUtils.quoteAndEscapeSql(mensaje.getNivelOrden()))
            .append(",")
            .append( mensaje.getSubOrden())
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(mensaje.getTipoMensaje()))
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(mensaje.getMensaje()))
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(mensaje.getIrANivelOrden()))
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(mensaje.getTextoInformativo()))
            .append("); ")
        ;
        return buffer.toString();
    }

    private AplicacionDeChatBot toAplicacionDeChatBot(MinotChatBotAplicacion chatBotAplicacion) {
        return  new AplicacionDeChatBot(chatBotAplicacion.getIdAplicacion(),chatBotAplicacion.getNombre(),chatBotAplicacion.getMensajeInicial());
    }

    private ChatBotInfo toChatBotInfo(MinotChatBotMensaje mensaje) {

        return new ChatBotInfo(mensaje.getNivelOrden(), mensaje.getTextoInformativo(), mensaje.getIrANivelOrden(), mensaje.getSubOrden(),
            mensaje.getTipoMensaje(), mensaje.getMensaje());


    }

}
