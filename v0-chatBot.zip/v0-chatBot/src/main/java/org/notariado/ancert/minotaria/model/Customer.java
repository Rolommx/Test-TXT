package org.notariado.ancert.minotaria.model;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import java.time.LocalDateTime;

@Entity
public class Customer {


     @Id
     @GeneratedValue(strategy = GenerationType.IDENTITY)
     private Long id;


    @NotBlank(message = "Name is mandatory")
    private String name;

    @NotBlank(message = "DNI is mandatory")
    private String dni;
 
    @Column(length = 512 )
    private String resume ;

    private int age;
    
    private LocalDateTime createdAt = LocalDateTime.now();

    public Customer() {
    	this.createdAt = LocalDateTime.now();

    }

    public Customer(String name, String dni, int age) {
    	  this();
        this.name = name;
        this.dni = dni;
        this.age = age;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDni(){
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int pAge) {
        this.age = pAge;
    }

    public String getResume() {
        return resume;
    }

    public void setResume(String pResume) {
        this.resume = pResume;
    }
    
    public LocalDateTime getCreationDate(){
    	return this.createdAt  ;
    }

    @Override
    public int hashCode() {
        final int prime = 31;
        int result = 1;
        result = prime * result + (int) (id ^ (id >>> 32));
        return result;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj)
            return true;
        if (obj == null)
            return false;
        if (getClass() != obj.getClass())
            return false;
        Customer other = (Customer) obj;
        if (id != other.id || ! this.dni.equals(other.dni))
            return false;
        return true;
    }

    @Override
    public String toString() {
        return "Customer [id=" + id + ", name=" + name + ", DNI=" + dni
                + ", age=" + age + " resume:" + resume+ "]";
    }

    
}
