package org.notariado.ancert.minotaria.repositories;

import java.util.List;

import org.notariado.ancert.minotaria.model.MinotChatBotPalabraClave;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


@Repository
public interface MinotChatBotPalabraClaveRepository extends JpaRepository<MinotChatBotPalabraClave,Long> {

      List<MinotChatBotPalabraClave> findAll();
/*
    List<DatosPalabraClave> buscarPorAppYTexto(Long idAplicacion, String textoABuscar);

    List<DatosPalabraClave> buscarPorAppYTexto(Long idAplicacion, String textoABuscar, boolean like);
*/
}
