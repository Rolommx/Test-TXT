package org.notariado.ancert.minotaria.repositories;

import java.util.List;

import org.notariado.ancert.minotaria.model.MinotChatBotMensaje;
import org.notariado.ancert.minotaria.model.MinotChatBotNavegacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MinotChatBotNavegacionRepository extends JpaRepository<MinotChatBotNavegacion, Long> {

    @Query(value = "SELECT nav FROM  MinotChatBotNavegacion  nav join nav.aplicacion app  WHERE nav.claveNavegacion = :pNivelOrden AND "
        + " app.idAplicacion = :pIdApp ORDER BY nav.orden")
    List<MinotChatBotNavegacion> obtenerPorApicacionYClaveNavegacion(@Param("pIdApp") Long idAplicacion,
        @Param("pNivelOrden") String claveNavegacion);

}
