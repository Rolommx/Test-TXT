package org.notariado.ancert.minotaria.business.vo.chatbot;

import java.util.ArrayList;
import java.util.List;
import org.notariado.ancert.minotaria.vo.ChatBotInfo;


public class ChatBotBusquedaDeTexto {

    private boolean busquedaExacta;

    private List<ChatBotInfo> resultados;

    public ChatBotBusquedaDeTexto(boolean busquedaExacta, List<ChatBotInfo> resultados) {
        this.busquedaExacta = busquedaExacta;
        this.resultados = resultados;
    }


    public boolean isBusquedaExacta() {
        return busquedaExacta;
    }

    public void setBusquedaExacta(boolean busquedaExacta) {
        this.busquedaExacta = busquedaExacta;
    }

    public int getTotalEncontrados() {
        return getResultados().size();
    }


    public List<ChatBotInfo> getResultados() {
        if (resultados == null) {
            resultados = new ArrayList<>();
        }
        return resultados;
    }

    public void setResultados(List<ChatBotInfo> resultados) {
        this.resultados = resultados;
    }
}
