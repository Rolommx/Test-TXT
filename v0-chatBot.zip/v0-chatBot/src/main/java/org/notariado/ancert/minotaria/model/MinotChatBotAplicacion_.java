package org.notariado.ancert.minotaria.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MinotChatBotAplicacion.class)
public abstract class MinotChatBotAplicacion_ {

	public static volatile SingularAttribute<MinotChatBotAplicacion, String> descripcion;
	public static volatile SingularAttribute<MinotChatBotAplicacion, Long> idAplicacion;
	public static volatile SingularAttribute<MinotChatBotAplicacion, String> mensajeInicial;
	public static volatile SingularAttribute<MinotChatBotAplicacion, String> nombre;

}

