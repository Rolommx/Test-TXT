package org.notariado.ancert.minotaria.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OrderBy;
import javax.persistence.Table;

@Entity
@Table(name = "MINOT_CHAT_BOT_NAVEGACION")
public class MinotChatBotNavegacion  implements Serializable {
    private static final long serialVersionUID = -7072449212352341009L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ID_APLICACION", nullable = false)
    private MinotChatBotAplicacion aplicacion;

    @Column(name = "TIPO_MENSAJE")
    private String tipoMensaje;

    @Column(name = "MENSAJE")
    private String mensaje;

    @Column(name = "CLAVE_NAVEGACION")
    private String claveNavegacion;

    @Column(name = "ORDEN")
    private Integer orden;

    @Column(name = "CLAVE_NAVEGACION_SGTE")
    private String irAClaveNavegacion;

    @OneToMany(mappedBy = "navegacion" )
    @OrderBy("orden")
    List<MinotChatBotOpcionNavegacion> opciones ;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MinotChatBotAplicacion getAplicacion() {
        return aplicacion;
    }

    public void setAplicacion(MinotChatBotAplicacion aplicacion) {
        this.aplicacion = aplicacion;
    }

    public String getTipoMensaje() {
        return tipoMensaje;
    }

    public void setTipoMensaje(String tipoMensaje) {
        this.tipoMensaje = tipoMensaje;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getClaveNavegacion() {
        return claveNavegacion;
    }

    public void setClaveNavegacion(String claveNavegacion) {
        this.claveNavegacion = claveNavegacion;
    }

    public Integer getOrden() {
        return orden;
    }

    public void setOrden(Integer orden) {
        this.orden = orden;
    }

    public String getIrAClaveNavegacion() {
        return irAClaveNavegacion;
    }

    public void setIrAClaveNavegacion(String irAClaveNavegacion) {
        this.irAClaveNavegacion = irAClaveNavegacion;
    }

    public List<MinotChatBotOpcionNavegacion> getOpciones() {
        if (opciones ==null ) {
            opciones = new ArrayList<>();
        }
        return opciones;
    }

    public void setOpciones(List<MinotChatBotOpcionNavegacion> opciones) {
        this.opciones = opciones;
    }
}