package org.notariado.ancert.minotaria.model;

import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(MinotChatBotMensaje.class)
public abstract class MinotChatBotMensaje_ {

	public static volatile SingularAttribute<MinotChatBotMensaje, String> textoInformativo;
	public static volatile SingularAttribute<MinotChatBotMensaje, String> nivelOrden;
	public static volatile SingularAttribute<MinotChatBotMensaje, Integer> subOrden;
	public static volatile SingularAttribute<MinotChatBotMensaje, String> irANivelOrden;
	public static volatile SingularAttribute<MinotChatBotMensaje, MinotChatBotAplicacion> aplicacion;
	public static volatile SingularAttribute<MinotChatBotMensaje, Long> id;
	public static volatile SingularAttribute<MinotChatBotMensaje, String> tipoMensaje;
	public static volatile SingularAttribute<MinotChatBotMensaje, String> mensaje;

}

