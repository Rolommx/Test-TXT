package org.notariado.ancert.minotaria.model;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "MINOT_CHAT_BOT_MENSAJE")
public class MinotChatBotMensaje /* implements Serializable */ {
    private static final long serialVersionUID = 8898254999118647482L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "ID_MENSAJE")
    private Long id;

    @ManyToOne
    @JoinColumn(name = "ID_APLICACION", nullable = false)
    private MinotChatBotAplicacion aplicacion;

    @Column(name = "TIPO_MENSAJE")
    private String tipoMensaje;

    @Column(name = "MENSAJE")
    private String mensaje;


    @Column(name = "NIVEL_ORDEN")
    private String nivelOrden;

    @Column(name = "SUB_ORDEN")
    private Integer subOrden;

    @Column(name = "IR_A_NIVEL_ORDEN")
    private String irANivelOrden;

    @Column(name = "TXT_INFO")
    private String textoInformativo;

    public String getTipoMensaje() {
        return tipoMensaje;
    }

    public void setTipoMensaje(String tipoMensaje) {
        this.tipoMensaje = tipoMensaje;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public MinotChatBotAplicacion getAplicacion() {
        return aplicacion;
    }

    public void setAplicacion(MinotChatBotAplicacion aplicacion) {
        this.aplicacion = aplicacion;
    }

    public String getMensaje() {
        return mensaje;
    }

    public void setMensaje(String mensaje) {
        this.mensaje = mensaje;
    }

    public String getNivelOrden() {
        return nivelOrden;
    }

    public void setNivelOrden(String nivelOrden) {
        this.nivelOrden = nivelOrden;
    }

    public Integer getSubOrden() {
        return subOrden;
    }

    public void setSubOrden(Integer subOrden) {
        this.subOrden = subOrden;
    }

    public String getIrANivelOrden() {
        return irANivelOrden;
    }

    public void setIrANivelOrden(String irANivelOrden) {
        this.irANivelOrden = irANivelOrden;
    }

    public String getTextoInformativo() {
        return textoInformativo;
    }

    public void setTextoInformativo(String textoInformativo) {
        this.textoInformativo = textoInformativo;
    }
}