package org.notariado.ancert.minotaria.business.service.chatbot;


import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import org.notariado.ancert.minotaria.business.vo.chatbot.ChatBotBusquedaDeTexto;
import org.notariado.ancert.minotaria.model.MinotChatBotAplicacion;
import org.notariado.ancert.minotaria.model.MinotChatBotNavegacion;
import org.notariado.ancert.minotaria.model.MinotChatBotOpcionNavegacion;
import org.notariado.ancert.minotaria.repositories.MinotChatBotNavegacionRepository;
import org.notariado.ancert.minotaria.util.StringUtils;
import org.notariado.ancert.minotaria.vo.AplicacionDeChatBot;
import org.notariado.ancert.minotaria.vo.ChatBotInfo;
import org.notariado.ancert.minotaria.vo.Opciones;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class ChatBotNavegacionServiceImpl implements ChatBotNavegacionService {

    private static Logger log = LoggerFactory.getLogger(ChatBotNavegacionServiceImpl.class);

    private final MinotChatBotNavegacionRepository navegacionRepository;

    public ChatBotNavegacionServiceImpl(MinotChatBotNavegacionRepository navegacionRepository) {
        this.navegacionRepository = navegacionRepository;
    }

    public List<ChatBotInfo> obtenerMensajesPorAppYClaveNavegacion(Long idApp, String claveNav, String cuv) {
        List<MinotChatBotNavegacion> data = navegacionRepository.obtenerPorApicacionYClaveNavegacion(idApp, claveNav);
        return data.stream().map(this::toChatBotInfo).collect(Collectors.toList());
    }


    public ChatBotBusquedaDeTexto obtenerMensajesPorAppYTexto(Long idAplicacion, String texto) {
        return new ChatBotBusquedaDeTexto(false, new ArrayList());

    }

    @Override
    public String getSQLInsertNavegacion() {
        List<MinotChatBotNavegacion> allMsgs = navegacionRepository.findAll();
        return allMsgs.stream().map(this::toInsertSQL).collect(Collectors.joining("\r\n"));
    }

    private String toInsertSQL(MinotChatBotNavegacion mensaje) {
        Collection<MinotChatBotOpcionNavegacion> opciones  =  mensaje.getOpciones();
        StringBuilder buffer = new StringBuilder(512);
        buffer.append("INSERT INTO MINOT_CHAT_BOT_NAVEGACION (ID,ID_APLICACION,CLAVE_NAVEGACION ,TIPO_MENSAJE,MENSAJE,ORDEN,"
            + "CLAVE_NAVEGACION_SGTE)   VALUES (")
            .append(mensaje.getId() +"              ")
            .append(",")
            .append(mensaje.getAplicacion().getIdAplicacion())
            .append(",")
           .append(StringUtils.quoteAndEscapeSql(mensaje.getClaveNavegacion()))
            .append(",")
            .append( StringUtils.quoteAndEscapeSql(mensaje.getTipoMensaje()))
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(mensaje.getMensaje()))
            .append(",")
            .append( mensaje.getOrden())
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(mensaje.getIrAClaveNavegacion()))
            .append("); ") ;

        List<String>  insertOpciones =  opciones.stream().map( this::toInsertOpcionesSQL).collect(Collectors.toList());
        if(! insertOpciones.isEmpty() ){
            buffer.append("\r\n ---- ## insert OPCIOES ## --- \r\n")
                  .append(insertOpciones.stream().collect(Collectors.joining("\r\n")))
                  .append("\r\n ---- ##  END insert OPCIOES ## ---\r\n");
        }
        return buffer.toString();
    }

    private String toInsertOpcionesSQL(MinotChatBotOpcionNavegacion opcion) {
        StringBuilder buffer = new StringBuilder(512);
        buffer.append("INSERT INTO MINOT_CHAT_BOT_OPCINES_NAVEGACION (ID,ID_NAVEGACION,MENSAJE,ORDEN,CLAVE_NAVEGACION_SGTE,ES_REGRESAR)"
            + " VALUES (")
            .append(opcion.getId() +"              ")
            .append(",")
            .append(opcion.getNavegacion().getId())
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(opcion.getMensaje()))
            .append(",")
            .append(opcion.getOrden())
            .append(",")
            .append(StringUtils.quoteAndEscapeSql(opcion.getIrAClaveNavegacion()))
            .append(",")
            .append(opcion.getEsRegresar())
            .append("); ");

        return buffer.toString();
    }

    private AplicacionDeChatBot toAplicacionDeChatBot(MinotChatBotAplicacion chatBotAplicacion) {
        return  new AplicacionDeChatBot(chatBotAplicacion.getIdAplicacion(),chatBotAplicacion.getNombre(),chatBotAplicacion.getMensajeInicial());
    }

    private ChatBotInfo toChatBotInfo(MinotChatBotNavegacion mensaje) {
        Predicate<Integer> esRegreso = intVal -> intVal != null && intVal == 1;
        List<Opciones> opciones = mensaje.getOpciones().stream()
            .map(opt -> new Opciones(opt.getMensaje(), opt.getIrAClaveNavegacion(), opt.getOrden(), esRegreso.test(opt.getEsRegresar())))
            .collect(Collectors.toList());

        return new ChatBotInfo(mensaje.getClaveNavegacion(), mensaje.getMensaje(), mensaje.getIrAClaveNavegacion(), mensaje.getOrden(),
            mensaje.getTipoMensaje(), mensaje.getMensaje(), opciones);


    }

}
