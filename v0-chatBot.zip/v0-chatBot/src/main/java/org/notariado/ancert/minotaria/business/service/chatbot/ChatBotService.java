package org.notariado.ancert.minotaria.business.service.chatbot;


import java.util.List;

import org.notariado.ancert.minotaria.business.vo.chatbot.ChatBotBusquedaDeTexto;
import org.notariado.ancert.minotaria.vo.AplicacionDeChatBot;
import org.notariado.ancert.minotaria.vo.ChatBotInfo;

public interface ChatBotService {

    List<ChatBotInfo> obtenerMensajesPorAppYClaveNavegacion(Long idApp, String claveNav, String cuv);


    ChatBotBusquedaDeTexto obtenerMensajesPorAppYTexto(Long idAplicacion, String texto);

    List<AplicacionDeChatBot> aplicacionesDeChatBotsDisponibles();

    String getSQLInsertMsgs();
}
