package org.notariado.ancert.minotaria.repositories;

import java.util.List;

import org.notariado.ancert.minotaria.model.MinotChatBotMensaje;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

@Repository
public interface MinotChatBotMensajeRepository extends JpaRepository<MinotChatBotMensaje, Long> {

    @Query(value = "SELECT msg FROM  MinotChatBotMensaje  msg join msg.aplicacion app  WHERE msg.nivelOrden = :pNivelOrden AND "
        + " app.idAplicacion = :pIdApp ORDER BY msg.subOrden")
    List<MinotChatBotMensaje> obtenerPorApicacionYClaveNavegacion(@Param("pIdApp") Long idAplicacion,
        @Param("pNivelOrden") String claveNavegacion);



    @Query(value = "SELECT msg FROM  MinotChatBotMensaje  msg join msg.aplicacion app  WHERE msg.nivelOrden = :pNivelOrden AND "
        + " app.idAplicacion = :pIdApp AND msg.subOrden = :pOrden   ORDER BY msg.subOrden")
    List<MinotChatBotMensaje> obtenerPorApicacionYClaveNavegacion(@Param("pIdApp") Long idAplicacion,
        @Param("pNivelOrden") String claveNavegacion, @Param("pOrden") Long orden);



}
