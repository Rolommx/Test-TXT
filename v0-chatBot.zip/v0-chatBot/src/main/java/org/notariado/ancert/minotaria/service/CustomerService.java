package org.notariado.ancert.minotaria.service;


import java.util.List;

import org.notariado.ancert.minotaria.model.Customer;

public interface CustomerService {
	
	Customer findById(long id);

	Customer findByDni(String dni);
	
	List<Customer> findByName(String name);
	
	Customer createCustomer(Customer product);
	
	void saveCustomer(Customer product);
	
	void updateCustomer(Customer product);
	
	void deleteCustomerById(long id);

	List<Customer> findAllCustomers();
	
	void deleteAllCustomers();
	
	boolean isCustomerExist(Customer product);
	
}
